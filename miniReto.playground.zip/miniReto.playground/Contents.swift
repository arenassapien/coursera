//: Playground - noun: a place where people can play

import UIKit
var serieNum = 0...100

for num in serieNum {
    
    if  num % 5 == 0{
         print("\(num)Bingo")
    }
    if num % 2 == 0 {
        print("\(num)par")
    }
    if num % 2 != 0 {
        print("\(num)impar")
    }
    if num >= 30 && num <= 40 {
        print("\(num)Viva Swift!!")
    }
    
    
}
